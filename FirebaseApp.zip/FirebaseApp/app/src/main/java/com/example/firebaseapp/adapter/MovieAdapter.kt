package com.example.firebaseapp.adapter

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.example.firebaseapp.R
import com.example.firebaseapp.model.Movie
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.database.FirebaseDatabase


class MovieAdapter(val mCtx:Context,val layoutResId:Int,val movieList:List<Movie>)
    : ArrayAdapter<Movie>(mCtx,layoutResId,movieList) {
    @SuppressLint("ViewHolder")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val layoutInflater: LayoutInflater = LayoutInflater.from(mCtx)
        val view: View = layoutInflater.inflate(layoutResId, null)

        val textViewName = view.findViewById<TextView>(R.id.textViewName)
        val textViewUpdate = view.findViewById<TextView>(R.id.textViewUpdate)

        val movie = movieList[position]
        textViewName.text =movie.name

        textViewUpdate.setOnClickListener {
            Log.d("Tagg","clicked")
            showUpdateDialog(movie)
        }


        return view
    }

    private fun showUpdateDialog(movie: Movie) {
        val builder = AlertDialog.Builder(mCtx)
        builder.setTitle("Update Movie")
        val inflater = LayoutInflater.from(mCtx)

        val view = inflater.inflate(R.layout.layout_update_movie, null)

        val editText = view.findViewById<TextInputLayout>(R.id.editTextUpdate)
        val ratingBar = view.findViewById<RatingBar>(R.id.ratingBar)

        /*editText.setText(movie.name)*/
        editText.editText?.setText(movie.name)
        val inputText = editText.editText?.text.toString()
        ratingBar.rating = movie.rating.toFloat()

        builder.setView(view)

        builder.setPositiveButton("Update") {p0, p1 ->
            val dbMovie = FirebaseDatabase.getInstance().getReference("movies")
            /*val name = editText.text.toString().trim()*/
            val name = editText.editText?.text.toString().trim()

            if(name.isEmpty()){
                editText.error = "Please enter a name"
                editText.requestFocus()
                return@setPositiveButton
            }
            val movie2 = Movie(movie.id, name, ratingBar.rating.toInt())

            dbMovie.child(movie.id).setValue(movie2)

            Toast.makeText(mCtx,"Movie updated", Toast.LENGTH_LONG).show()

        }

        builder.setNegativeButton("No") { p0, p1 ->
        }
         val alert = builder.create()
         alert.show()
    }
}



/*class MovieAdapter (val mCtx:Context,val layoutResId:Int,val movieList:MutableList<Movie>)
    : RecyclerView.Adapter<MovieAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.movies, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return movieList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        var movie=movieList[position]
        holder.movieName.setText(holder.adapterPosition)
        holder.movieRatingBar.rating= movie.rating.toFloat()
    }*/

  /*  override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val layoutInflater: LayoutInflater = LayoutInflater.from(mCtx)
        val view: View = layoutInflater.inflate(layoutResId, null)

        val textViewName = view.findViewById<TextView>(R.id.textView)

        val movie = movieList[position]

        textViewName.text = movie.name
        return view
    }*/

    /*class ViewHolder(view: View): RecyclerView.ViewHolder(view){

        val movieView=view
        var movieName=view.findViewById<EditText>(R.id.textViewName)
        var movieRatingBar=view.findViewById<RatingBar>(R.id.ratingBar)
        //var deleteButton=view.findViewById<Button>(R.id.deleteButton)
    }}
*/
